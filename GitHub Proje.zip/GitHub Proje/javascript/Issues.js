
 
 
 /* Issues-Tablinks */ 

 function openCity(evt, cityName) {
    var i, tabcontentrequest, tablinks;
    tabcontent = document.getElementsByClassName("tabcontentrequest");
    for (i = 0; i < tabcontent.length; i++) {
      tabcontent[i].style.display = "none";
    }
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
      tablinks[i].className = tablinks[i].className.replace("active", "");
    }
    document.getElementById(cityName).style.display = "block";
    evt.currentTarget.className += " active";
  }
  document.getElementById("defaultOpen").click();

 /* Issues-Tablinks */ 


  /* Modals */   

  var modal = document.querySelector('.modal');
  var dropdown = document.querySelector('.Dropdown');
  var close = document.querySelector('#close');
  dropdown.addEventListener('click', function () {

    modal.style.display = "block";
  });

  close.addEventListener('click', function () {

    modal.style.display = "none";
  });


  var bell = document.querySelector("#bell");
  var content = document.querySelector("#bell-textcontent");
  var modal1 = document.querySelector(".modal1");

  function mouseOver() {
    content.style.display = "block";
    modal1.style.display = "block";
    content.textContent = "You have no unread notifications";
  }

  function mouseOut() {
    modal1.style.display = "none";
    content.style.display = "none";
  }


  var modal2 = document.querySelector(".modal2");
  var dropdown1 = document.querySelector(".Dropdown-1");
  var close1 = document.querySelector('#close-1');

  dropdown1.addEventListener("click", function () {
    modal2.style.display = "block";
  });

  close1.addEventListener("click", function () {
    modal2.style.display = "none";
  });

  var navbarlabel = document.querySelector("#navbar-label");
  var modal3 = document.querySelector("#modal-3");


  function mouseOvers() {
    
    navbarlabel.style.width = "400px";
    navbarlabel.style.transition = "0.4s";
    navbarlabel.style.borderTop = "1px solid #30363d";
    navbarlabel.style.borderRight = "1px solid #30363d";
    navbarlabel.style.borderLeft = "1px solid #30363d";
    navbarlabel.style.borderBottom = "1px solid #30363d";
    navbarlabel.style.borderBottomRightRadius = "0px";
    navbarlabel.style.borderBottomLeftRadius = "0px";

    modal3.style.display= "block";
    modal3.style.borderLeft = "1px solid #30363d";
    modal3.style.borderRight = "1px solid #30363d";
    modal3.style.borderBottom = "1px solid #30363d";
    modal3.style.borderTop = "1px solid #30363d";
    modal3.style.borderTopRightRadius = "0px";
    modal3.style.borderTopLeftRadius = "0px";
    modal3.style.width = "400px";
    modal3.style.transition = "0.4s";
  }

  function mouseOuts() {
    navbarlabel.style.borderRadius="6px";
    navbarlabel.style.width = "270px";
    modal3.style.display= "none";
  }

   /* Modals */   

